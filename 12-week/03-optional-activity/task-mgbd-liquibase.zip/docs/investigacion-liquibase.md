# Investigación Liquibase
Liquibase es una herramienta para control de versiones de bases de datos.
Permite gestionar cambios mediante changelogs y changesets.
