CREATE TABLE factura (
    id SERIAL PRIMARY KEY,
    fecha TIMESTAMP,
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);
