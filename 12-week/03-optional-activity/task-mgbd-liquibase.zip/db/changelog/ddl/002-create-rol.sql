CREATE TABLE rol (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50)
);
