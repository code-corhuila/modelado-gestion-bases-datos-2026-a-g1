INSERT INTO persona(nombre, apellido, correo) VALUES ('Ana', 'Lopez', 'ana@mail.com');
INSERT INTO rol(nombre) VALUES ('Admin');
INSERT INTO usuario(username, password, persona_id, rol_id) VALUES ('admin', '1234', 1, 1);
INSERT INTO producto(nombre, precio) VALUES ('Laptop', 2500);
INSERT INTO factura(fecha, usuario_id) VALUES (NOW(), 1);
INSERT INTO detalle_factura(factura_id, producto_id, cantidad) VALUES (1,1,2);
