# Taller Liquibase - CORHUILA

## Requisitos
- Docker instalado

## Ejecución
```bash
docker compose down -v
docker compose up -d db

docker compose run --rm liquibase validate
docker compose run --rm liquibase update
docker compose run --rm liquibase status --verbose
```

## Validación
```bash
docker compose exec db psql -U postgres -d mgbd_liquibase -c "\dt"
```
